Session-keep-open (Chrome extension)
(Actually made just for ‘Chrome’ browser)


This extension will help maintain your session running on any platform that has a limited login time —which unnecessarily disrupts you— without requiring continuous manual logins.



How to Install
    1. Create the folder and files as described above
    2. You can create simple icons or use placeholder images named icon16.png, icon48.png, and icon128.png in an "images" folder
    3. In Chrome:
        ◦ Go to chrome://extensions/
        ◦ Enable "Developer mode" (toggle in top right)
        ◦ Click "Load unpacked"
        ◦ Select your extension folder


How to Use
    1. Click the extension icon in your toolbar
    2. Enter the number of minutes between refreshes (e.g., 30 for half-hour refreshes)
    3. Click "Save & Activate"
    4. The page will now automatically refresh at your specified interval
    5. Click "Stop" to disable auto-refresh.
    6.  This extension will help maintain your session running on any platform that has a limited login time —which unnecessarily disrupts you— without requiring continuous manual logins.