let refreshAlarm = null;

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "start") {
    // Clear any existing alarm
    if (refreshAlarm) {
      chrome.alarms.clear(refreshAlarm);
    }

    // Set new alarm
    const minutes = request.minutes;
    chrome.alarms.create("refreshAlarm", { delayInMinutes: minutes, periodInMinutes: minutes });
    refreshAlarm = "refreshAlarm";

    // Save the interval
    chrome.storage.sync.set({ refreshInterval: minutes });

  } else if (request.action === "stop") {
    if (refreshAlarm) {
      chrome.alarms.clear(refreshAlarm);
      refreshAlarm = null;
    }
  }
});

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === "refreshAlarm") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.reload(tabs[0].id);
      }
    });
  }
});