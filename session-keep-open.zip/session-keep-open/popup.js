document.addEventListener('DOMContentLoaded', function() {
  const minutesInput = document.getElementById('minutes');
  const saveButton = document.getElementById('save');
  const stopButton = document.getElementById('stop');
  const statusDiv = document.getElementById('status');

  // Load saved interval
  chrome.storage.sync.get(['refreshInterval'], function(result) {
    if (result.refreshInterval) {
      minutesInput.value = result.refreshInterval;
      updateStatus(true);
    }
  });

  saveButton.addEventListener('click', function() {
    const minutes = parseInt(minutesInput.value);
    if (minutes && minutes > 0) {
      chrome.storage.sync.set({ refreshInterval: minutes }, function() {
        chrome.runtime.sendMessage({ action: "start", minutes: minutes });
        updateStatus(true);
      });
    } else {
      alert("Please enter a valid number of minutes (1 or more)");
    }
  });

  stopButton.addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: "stop" });
    updateStatus(false);
  });

  function updateStatus(isActive) {
    statusDiv.textContent = `Status: ${isActive ? 'Active' : 'Inactive'}`;
    statusDiv.style.color = isActive ? 'green' : 'red';
  }
});