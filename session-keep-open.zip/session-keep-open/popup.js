document.addEventListener('DOMContentLoaded', function() {
  const minutesInput = document.getElementById('minutes');
  const saveButton = document.getElementById('save');
  const stopButton = document.getElementById('stop');
  const statusDiv = document.getElementById('status');
  
  // Very long interval for effectively disabling refreshes when stopped
  const EXTREMELY_LONG_INTERVAL = 100000000000000000000000000000000000000000000000000000000000000;

  // Load saved interval and state
  chrome.storage.sync.get(['refreshInterval', 'isGreyscale', 'isActive'], function(result) {
    if (result.refreshInterval && result.isActive !== false) {
      minutesInput.value = result.refreshInterval;
    } else {
      // Clear the input field if inactive
      minutesInput.value = '';
    }
    
    // Apply greyscale if previously set
    if (result.isGreyscale) {
      applyGreyscale();
    }
  });

  saveButton.addEventListener('click', function() {
    const minutes = parseInt(minutesInput.value);
    if (minutes && minutes > 0) {
      chrome.storage.sync.set({ 
        refreshInterval: minutes, 
        isGreyscale: false,
        isActive: true 
      }, function() {
        chrome.runtime.sendMessage({ action: "start", minutes: minutes });
        updateStatus(true);
        resetColors();
      });
    } else {
      alert("Please enter a valid number of minutes (1 or more)");
    }
  });

  stopButton.addEventListener('click', function() {
    // Set extremely long interval instead of stopping completely
    chrome.runtime.sendMessage({ action: "start", minutes: EXTREMELY_LONG_INTERVAL });
    // Clear the input field
    minutesInput.value = '';
    updateStatus(false);
    chrome.storage.sync.set({ 
      isGreyscale: true,
      isActive: false
    });
    applyGreyscale();
  });

  function updateStatus(isActive) {
    statusDiv.textContent = `Status: ${isActive ? 'Active' : 'Inactive'}`;
    statusDiv.style.color = isActive ? 'green' : 'red';
  }
  
  function applyGreyscale() {
    // Make the entire interface greyscale
    document.body.style.backgroundColor = "#f0f0f0";
    document.querySelector('h3').style.color = "#555";
    document.querySelector('.credit').style.color = "#999";
    
    // Make buttons darker grey
    document.querySelectorAll('button').forEach(button => {
      button.style.backgroundColor = "#777";
      button.style.color = "#eee";
    });
    
    // Make input field grey
    minutesInput.style.backgroundColor = "#e5e5e5";
    minutesInput.style.color = "#555";
    minutesInput.style.borderColor = "#999";
  }
  
  function resetColors() {
    // Reset to original colors
    document.body.style.backgroundColor = "";
    document.querySelector('h3').style.color = "";
    document.querySelector('.credit').style.color = "";
    
    document.querySelectorAll('button').forEach(button => {
      if (button.id === 'save') {
        button.style.backgroundColor = "#4CAF50";
      } else {
        button.style.backgroundColor = "";
      }
      button.style.color = "";
    });
    
    minutesInput.style.backgroundColor = "";
    minutesInput.style.color = "";
    minutesInput.style.borderColor = "";
  }
});